import type { ButtonHTMLAttributes } from 'react';

type Variant = 'primary' | 'ghost' | 'danger';
type Size = 'sm' | 'md';

/**
 * A small action set keeps primary intent, quiet navigation actions and destructive actions
 * visually distinct without adding extra styles to every page.
 */
const variant: Record<Variant, string> = {
  primary: 'bg-block text-on-block font-bold shadow-[0_8px_24px_rgba(33,106,73,0.16)] hover:brightness-105 active:translate-y-px',
  ghost: 'border border-line bg-elevated/55 text-primary hover:border-muted/70 hover:bg-elevated',
  danger: 'border border-danger/35 bg-danger/5 text-danger hover:border-danger/60 hover:bg-danger/10',
};

const size: Record<Size, string> = {
  sm: 'h-9 px-3.5 text-sm',
  md: 'h-11 px-5',
};

/**
 * The recipe, on its own.
 *
 * A route that navigates is a link, not a button that navigates, so anything styled like a
 * button and pointing at a URL needs these classes without the `<button>` element.
 */
export function buttonClass(v: Variant = 'primary', s: Size = 'md', className = ''): string {
  return `inline-flex items-center justify-center gap-2 rounded-xl transition-[background,color,border-color,box-shadow,transform] duration-200 disabled:pointer-events-none disabled:opacity-45 ${size[s]} ${variant[v]} ${className}`;
}

export function Button({
  variant: v = 'primary',
  size: s = 'md',
  loading = false,
  className = '',
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
}) {
  return (
    <button
      {...rest}
      disabled={loading || rest.disabled}
      aria-busy={loading || undefined}
      className={buttonClass(v, s, className)}
    >
      {loading ? <span aria-hidden>…</span> : null}
      {children}
    </button>
  );
}
