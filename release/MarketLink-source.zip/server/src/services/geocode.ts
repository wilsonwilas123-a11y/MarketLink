import { z } from 'zod';
import { ApiError } from '../errors.js';
import type { PlaceCandidate } from '../api/schemas.js';

/**
 * Place lookup against OpenStreetMap, for finding a pin before a row exists.
 *
 * The site needs coordinates for two things it cannot derive from its own data: a market an
 * admin is adding, and a stall a farmer is pinning. Both are a name typed into a box, and a
 * lat/lng guessed from memory puts a marker in a lagoon. This reads the same gazetteer the
 * map tiles come from, so a pin that resolves here is a pin the map will draw in the right
 * place.
 *
 * A third caller arrived with the pan-African scope: the discovery screens, which show a
 * visitor the markets the map knows about that this database has not heard of yet. That one
 * has no token in front of it, which is why the cache in `makeCachedGeocoder` lives here
 * rather than in the route — the guarantee is about the upstream, not about one path.
 *
 * Three rules shape the module. The host is a constant rather than an argument: a route that
 * forwarded a caller-supplied URL would be an open proxy with our credentials on it, and
 * only the query text is user input. The upstream is treated as an unreliable witness
 * throughout — a fixed timeout, a reply narrowed by zod, and every failure converted to one
 * of the spec 9.1 codes, so a Komoot outage surfaces as a clean 500 with a request id rather
 * than as a hung socket or a shape the client was never told about. And a question is asked
 * once.
 */
const PHOTON_ENDPOINT = 'https://photon.komoot.io/api/';

/** Long enough for a cold gazetteer query; short enough that a route never outlives a proxy timeout. */
const TIMEOUT_MS = 6_000;

/** The tag OpenStreetMap puts on a place where people sell produce at stalls. */
export const MARKETPLACE_KIND = 'amenity/marketplace';

/**
 * How much more than asked for to fetch when filtering to marketplaces.
 *
 * Photon has no tag filter: `osm_value=marketplace` is accepted and then answers with nothing,
 * so a market search has to over-fetch and keep the rows whose `kind` is right. Four is what a
 * city query like `market Ibadan` needs — it returns two real markets beside an expressway, a
 * neighbourhood and an electronics shop.
 */
const OVERFETCH = 4;

/** The ceiling on the upstream's own `limit`, however much was asked for. */
const MAX_UPSTREAM_LIMIT = 50;

/**
 * The word that turns a place search into a market search.
 *
 * A bare town name ranks the town, its streets and its stations: `Kumasi` and `Cape Town` each
 * answered with no marketplace at all on 2026-09-26, while `Kumasi market` answered with four of
 * them. This endpoint only ever returns marketplaces, so the category belongs in the question.
 * A term that already says it is left alone rather than asked twice.
 */
function asMarketQuery(query: string): string {
  return /\bmarkets?\b/i.test(query) ? query : `${query} market`;
}

/**
 * Rough bounding box around the whole African continent and its island nations, in Photon's
 * own `minLon,minLat,maxLon,maxLat` order.
 *
 * This is sent as a hint to Photon so it does not spend its ranking on candidates the product
 * has no use for, and — because Photon favours matches inside a supplied bbox — it also sharpens
 * precision for an ambiguous name that exists in more than one country. It is deliberately loose
 * (it also covers a sliver of the Middle East and southern Europe); `isInAfrica` below is the
 * actual, exact filter.
 */
const AFRICA_BBOX = '-25.5,-35.5,63.5,38.0';

/**
 * Every recognised African country's English name, in the spellings Photon's OpenStreetMap
 * data tends to use, so a candidate is kept only when it is actually inside Africa. `AFRICA_BBOX`
 * alone would let through, say, Israel or Greece — this is what excludes them.
 */
const AFRICAN_COUNTRIES = new Set([
  'algeria', 'angola', 'benin', 'botswana', 'burkina faso', 'burundi', 'cabo verde', 'cape verde',
  'cameroon', 'central african republic', 'chad', 'comoros', 'congo',
  'democratic republic of the congo', 'republic of the congo', 'djibouti', 'egypt',
  'equatorial guinea', 'eritrea', 'eswatini', 'swaziland', 'ethiopia', 'gabon', 'gambia', 'ghana',
  'guinea', 'guinea-bissau', "côte d'ivoire", 'ivory coast', 'kenya', 'lesotho', 'liberia', 'libya',
  'madagascar', 'malawi', 'mali', 'mauritania', 'mauritius', 'morocco', 'mozambique', 'namibia',
  'niger', 'nigeria', 'rwanda', 'sao tome and principe', 'são tomé and príncipe', 'senegal',
  'seychelles', 'sierra leone', 'somalia', 'south africa', 'south sudan', 'sudan', 'tanzania',
  'togo', 'tunisia', 'uganda', 'zambia', 'zimbabwe',
]);

function isInAfrica(country: string | null): boolean {
  return country !== null && AFRICAN_COUNTRIES.has(country.trim().toLowerCase());
}

/* ---------------------------------------------------------------- the map's own markets

   A gazetteer answers a name. It cannot answer "what is in this corner of the map", which is
   the question a discovery screen asks before anyone has typed anything. That is a database
   query over the OSM replication data, so it goes to Overpass, and Overpass is a third party
   running mirrors on volunteer patience — hence the box cap below and the cache around the
   whole module. */

/**
 * The public Overpass mirrors, tried in order.
 *
 * `overpass-api.de` is the reference instance and the most heavily loaded of the three: on its
 * own it times out or answers 504 often enough that a route built on it alone is not something
 * a visitor can depend on. The other two mirror the same replication data on different
 * hardware, so a query that stalls on one succeeds on another without changing the answer.
 */
const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.openstreetmap.ru/api/interpreter',
];

/**
 * Both the asking and the giving-up, per mirror.
 *
 * A bounded box of named nodes answers in a couple of seconds; eight is the point at which a
 * queued mirror has cost a visitor more than moving on to the next mirror is worth. Three
 * mirrors at 8s worst case is still faster, and usually far faster, than one mirror hanging
 * for twice as long before the route gives up.
 */
const OVERPASS_TIMEOUT_S = 8;

/**
 * The largest corner of the map one request may cover, in degrees.
 *
 * ~66 km north-to-south, which is more than a visitor can see at one time at the zoom the map
 * opens at. The cap is the reason this route can be public: an unbounded box is an invitation to
 * make a volunteer mirror read the continent on our behalf, and the tenth time it runs a
 * whole-Africa query is the tenth mirror that stops answering us.
 */
const MAX_BOX_SPAN = 0.6;

/** A corner of the map, in the order Overpass wants it: `south,west,north,east`. */
export interface MarketBox {
  south: number;
  west: number;
  north: number;
  east: number;
}

/**
 * `6.4,3.2,6.7,3.6` from a query string, or a rejection that says which part was wrong.
 *
 * Parsed here rather than in the route because the shape is the upstream's dialect while the
 * rules — inside the world, north above south, small enough to ask — are ours.
 */
export function parseMarketBox(raw: string): MarketBox {
  // Plain decimals only. An empty part would read as `0`, which is a point in the Gulf of
  // Guinea rather than a mistake, and these four numbers are the only thing that reaches the
  // upstream query.
  const parts = raw.split(',').map((part) => part.trim());

  if (parts.length !== 4 || parts.some((part) => !/^-?\d+(\.\d{1,6})?$/.test(part))) {
    throw new ApiError(
      'validation_failed',
      'bbox has to be four numbers: south,west,north,east.',
    );
  }

  const [south, west, north, east] = parts.map(Number) as [number, number, number, number];

  if (Math.abs(south) > 90 || Math.abs(north) > 90 || Math.abs(west) > 180 || Math.abs(east) > 180) {
    throw new ApiError('validation_failed', 'bbox is outside the world as we know it.');
  }

  if (north <= south || east <= west) {
    throw new ApiError('validation_failed', 'bbox has to run north and east from its corner.');
  }

  // `+ 1e-9` because the corners arrive by subtraction and floating point is what it is: a box
  // asked for as `6.4,3.1,6.8,3.7` measures 0.6000000000000001 across, and refusing a visitor's
  // honest viewport at the exact limit is not what the cap is for.
  if (north - south > MAX_BOX_SPAN + 1e-9 || east - west > MAX_BOX_SPAN + 1e-9) {
    throw new ApiError(
      'validation_failed',
      `bbox covers more than ${MAX_BOX_SPAN}° across. Ask for the corner a visitor can see.`,
    );
  }

  return { south, west, north, east };
}

/**
 * Nodes only, not ways.
 *
 * A marketplace mapped as a building outline would be missed, and that is accepted: ways make
 * the reply larger and slower for every query, and the node set already carries the gates
 * somebody cared enough to name.
 */
function boxQuery(box: MarketBox, wanted: number): string {
  const { south, west, north, east } = box;
  return (
    `[out:json][timeout:${OVERPASS_TIMEOUT_S}];` +
    `node["amenity"="marketplace"](${south},${west},${north},${east});` +
    `out ${wanted};`
  );
}

/** The two fields of a `fetch` reply this module reads, so a test can hand over an object. */
export interface GeocodeReply {
  ok: boolean;
  status: number;
  json(): Promise<unknown>;
}

export interface GeocodeRequest {
  headers: Record<string, string>;
  signal: AbortSignal;
  /** Overpass takes the query in the body; a GET needs no method at all. */
  method?: string;
  body?: string;
}

export type GeocodeFetch = (url: string, init: GeocodeRequest) => Promise<GeocodeReply>;

/** The whole surface the routes use. */
export interface Geocoder {
  search(query: string, limit: number): Promise<PlaceCandidate[]>;
  /**
   * Places the map tags as a marketplace.
   *
   * Ranked by the gazetteer's own text match, not by distance or by how much is stocked there,
   * and capped at what was asked for after the tag filter runs. The term reaches the upstream as
   * a market question, so what is on the wire is not always what the caller passed.
   */
  markets(query: string, limit: number): Promise<PlaceCandidate[]>;
  /**
   * Marketplaces inside one corner of the map, for a screen nobody has typed into yet.
   *
   * A different upstream answers this one, and it answers with whatever is there rather than
   * with what matches a name, so the order carries no ranking and nodes whose `name` tag is empty
   * are dropped: an unnamed ring on a map tells a visitor nothing they can act on.
   */
  inBox(box: MarketBox, limit: number): Promise<PlaceCandidate[]>;
}

/**
 * Photon's `properties`, as far as we rely on it.
 *
 * Everything is optional because the gazetteer fills in what it has: a marketplace node often
 * carries a name and nothing else, while a street address carries both.
 */
const PhotonFeatureSchema = z.object({
  geometry: z.object({
    type: z.literal('Point'),
    coordinates: z.tuple([z.number(), z.number()]),
  }),
  properties: z.object({
    osm_type: z.string().optional(),
    osm_id: z.number().int().optional(),
    osm_key: z.string().optional(),
    osm_value: z.string().optional(),
    name: z.string().min(1).optional(),
    street: z.string().optional(),
    housenumber: z.string().optional(),
    locality: z.string().optional(),
    district: z.string().optional(),
    city: z.string().optional(),
    county: z.string().optional(),
    state: z.string().optional(),
    postcode: z.string().optional(),
    country: z.string().optional(),
  }),
});

const PhotonResponseSchema = z.object({ features: z.array(z.unknown()) });

type PhotonFeature = z.infer<typeof PhotonFeatureSchema>;

/** One line, most specific first, with whatever the place did not supply left out. */
function addressOf(p: PhotonFeature['properties']): string {
  const street = [p.housenumber, p.street].filter(Boolean).join(' ');
  const town = p.city ?? p.district ?? p.locality ?? p.county;
  return [street, town, p.postcode, p.state, p.country].filter(Boolean).join(', ');
}

/**
 * `w2453679849` — the element reference OpenStreetMap itself uses in a URL.
 *
 * Kept whole rather than split into type and id, because its only jobs are to deduplicate a
 * result set and to let a human open the source and check it.
 */
function refOf(p: PhotonFeature['properties']): string {
  if (p.osm_id === undefined) return 'unnamed';
  return `${(p.osm_type ?? 'N').toLowerCase()}${p.osm_id}`;
}

function candidateOf(feature: PhotonFeature): PlaceCandidate {
  const { properties: p, geometry } = feature;
  const [lng, lat] = geometry.coordinates;
  const city = p.city ?? p.district ?? p.locality ?? p.county ?? null;
  const address = addressOf(p);

  return {
    ref: refOf(p),
    name: marketName(p.name, city, address),
    lat,
    lng,
    address,
    city,
    state: p.state ?? null,
    country: p.country ?? null,
    kind: p.osm_key && p.osm_value ? `${p.osm_key}/${p.osm_value}` : (p.osm_key ?? 'place'),
    image_url: null,
    image_credit: null,
    image_link: null,
  };
}

/** OSM often labels unnamed neighbourhood stalls simply "Market"; make that label useful. */
function marketName(name: string | undefined, area: string | null, address: string): string {
  if (name && significantWords(name).length > 0) return name;
  const place = area || address.split(',')[0]?.trim();
  return place ? `Market in ${place}` : (name || 'Unnamed market');
}

/**
 * One Overpass element.
 *
 * `name` is required where Photon's is optional: an untagged node in a box is a marketplace
 * nobody has ever labelled, and a ring with no name behind it is not a choice a visitor can make.
 */
const OverpassElementSchema = z.object({
  type: z.literal('node'),
  id: z.number().int(),
  lat: z.number(),
  lon: z.number(),
  tags: z.object({ name: z.string().min(1) }).catchall(z.unknown()),
});

const OverpassResponseSchema = z.object({ elements: z.array(z.unknown()) });

type OverpassElement = z.infer<typeof OverpassElementSchema>;

/**
 * The same `PlaceCandidate` shape, assembled from raw tags.
 *
 * Overpass resolves nothing: Photon hands back a formatted address and this has to build one out
 * of whichever `addr:*` keys the mapper happened to fill in, which for most market gates in
 * Nigeria is none of them. An empty `address` is the honest answer, not a failure.
 */
function boxCandidateOf(el: OverpassElement): PlaceCandidate {
  const tags = el.tags;
  const text = (key: string): string | null => {
    const value = tags[key];
    return typeof value === 'string' && value.trim() !== '' ? value.trim() : null;
  };

  const city = text('addr:city') ?? text('addr:town') ?? text('addr:village') ?? text('addr:suburb');

  return {
    ref: `n${el.id}`,
    name: marketName(tags.name, city, [text('addr:street'), city].filter(Boolean).join(', ')),
    lat: el.lat,
    lng: el.lon,
    address: [text('addr:street'), city, text('addr:postcode'), text('addr:state'), text('addr:country')]
      .filter(Boolean)
      .join(', '),
    city,
    state: text('addr:state'),
    country: text('addr:country'),
    kind: MARKETPLACE_KIND,
    image_url: null,
    image_credit: null,
    image_link: null,
  };
}

/* ---------------------------------------------------------------- real photos, best-effort

   OpenStreetMap carries no photos at all, so a real image has to come from somewhere else.
   Wikipedia is the option that needs no API key and no billing: a market with any web presence
   usually has an article, and `pageimages` hands back a real thumbnail for it. Most small,
   locally-known markets will have no article and get `null`, which the frontend already
   treats as "no photo yet" and falls back to the pin — this only ever adds a photo, it never
   removes the fallback. */

const WIKIPEDIA_API = 'https://en.wikipedia.org/w/api.php';

/** Photos are a nice-to-have, not the reason a market list is slow — this is not the 6-8s
 * budget the two real geocoders get. */
const PHOTO_TIMEOUT_MS = 3_500;

/** The one shape read out of Wikipedia's response; everything else in it is ignored.
 * `title` is included because it is the only thing that lets us check the search actually
 * found the place asked about, rather than something that merely shares a word with it. */
const WikiPhotoResponseSchema = z.object({
  query: z
    .object({
      pages: z
        .record(
          z.object({
            title: z.string(),
            thumbnail: z.object({ source: z.string() }).optional(),
            // Present only when the article itself is tagged with a location — most articles
            // about a person, brand, or generic topic have none, but an article about an actual
            // place usually does, and that is exactly the case this needs to catch.
            coordinates: z.array(z.object({ lat: z.number(), lon: z.number() })).optional(),
          }),
        )
        .optional(),
    })
    .optional(),
});

/** Great-circle distance in kilometres — the plain haversine formula, nothing fancier. */
function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/**
 * How far a matched article's own coordinates may sit from the market's pin and still be
 * trusted as the same place.
 *
 * Generous on purpose — a city-level Wikipedia coordinate can be several kilometres from a
 * specific market gate — but nowhere near generous enough to let a same-named place on another
 * continent through. "Children's place Plaza" in Lagos matching Wikipedia's article on a
 * "The Children's Place" store in Valdosta, Georgia is the case this exists to catch: two
 * genuinely different places that happen to share both specific words in their name.
 */
const MAX_COORD_DISTANCE_KM = 80;

/**
 * Words too generic, in either a market name or a Wikipedia title, to prove a match on their
 * own. Without this list "Community Market" would validate against literally any article
 * whose title contains the word "market" or "community".
 */
const GENERIC_NAME_WORDS = new Set([
  'market', 'markets', 'plaza', 'the', 'main', 'central', 'new', 'old', 'community', 'public',
]);

/** The words in a place's name specific enough to prove a Wikipedia hit is about that place. */
function significantWords(name: string): string[] {
  return name
    .toLowerCase()
    .split(/[^a-z0-9]+/)
    .filter((word) => word.length >= 3 && !GENERIC_NAME_WORDS.has(word));
}

/**
 * Whether a Wikipedia article's title is actually likely to be about this place.
 *
 * `generator=search` ranks by whatever text match it can find anywhere on the page, so its top
 * hit for an obscure local market name is often a biography or a village that shares one word
 * with it — the "Bola Kasim market" search that returned a photo of an unrelated person is
 * exactly that failure mode. Requiring at least one *specific* word from the place's name to
 * appear in the matched title is a blunt filter, but a false "no photo" costs nothing (the pin
 * glyph is the honest fallback already) while a false photo actively misleads a visitor.
 */
function titleMatchesPlace(title: string, placeName: string): boolean {
  const words = significantWords(placeName);
  if (words.length === 0) return false;

  const lowerTitle = title.toLowerCase();
  // A search result about a business, town or person can share every distinctive word with
  // a local market. Require the article title itself to identify a market before its photo
  // can represent one; Mapillary's coordinate search remains the fallback for other names.
  if (!/\bmarkets?\b/.test(lowerTitle)) return false;
  const matches = words.filter((word) => lowerTitle.includes(word)).length;

  // A name with only one specific word ("Oyingbo Market") has nothing else to check against,
  // so that one word matching is the whole test. A name with two or more must match at least
  // two. The market-title requirement above is equally important: "Children's Place" can
  // match two words from "Children's Place Plaza", but it is a US retail brand, not a Lagos
  // marketplace, so its photo must never stand in for one.
  const required = Math.min(2, words.length);
  return matches >= required;
}

/**
 * The best photo Wikipedia has for a place, or `null` — never a thrown error.
 *
 * A search title has to be built rather than looked up directly, because a `PlaceCandidate`'s
 * name is what OpenStreetMap called it, not necessarily what Wikipedia titled its article on
 * the same place. `generator=search` does that matching for us: the top hit for "Mile 12
 * Market Lagos" is the market's own article when one exists, and something unrelated or
 * nothing at all when it doesn't — either way this returns `null` rather than a wrong photo,
 * since `pageimages` only fires for pages that actually carry an image.
 */
interface PlacePhoto { url: string; credit: string; link: string }

async function photoFor(
  fetchImpl: GeocodeFetch,
  headers: Record<string, string>,
  name: string,
  city: string | null,
  lat: number,
  lng: number,
): Promise<PlacePhoto | null> {
  const query = city ? `${name} market ${city}` : `${name} market`;
  const url = `${WIKIPEDIA_API}?${new URLSearchParams({
    action: 'query',
    generator: 'search',
    gsrsearch: query,
    gsrlimit: '1',
    prop: 'pageimages|coordinates',
    piprop: 'thumbnail',
    pithumbsize: '640',
    format: 'json',
  })}`;

  try {
    const reply = await fetchImpl(url, {
      headers,
      signal: AbortSignal.timeout(PHOTO_TIMEOUT_MS),
    });
    if (!reply.ok) return null;

    const parsed = WikiPhotoResponseSchema.safeParse(await reply.json());
    if (!parsed.success) return null;

    const pages = parsed.data.query?.pages;
    if (!pages) return null;

    const first = Object.values(pages)[0];
    if (!first?.thumbnail || !titleMatchesPlace(first.title, name)) return null;

    // The stronger check: if the article carries its own coordinates and they are nowhere
    // near this market, no amount of matching words makes it the right photo. An article
    // with no coordinates at all (most non-place articles) falls through to trusting the
    // text match alone, same as before.
    const coord = first.coordinates?.[0];
    if (coord && haversineKm(lat, lng, coord.lat, coord.lon) > MAX_COORD_DISTANCE_KM) {
      return null;
    }

    return {
      url: first.thumbnail.source,
      credit: 'Wikipedia article',
      link: `https://en.wikipedia.org/wiki/${encodeURIComponent(first.title.replaceAll(' ', '_'))}`,
    };
  } catch {
    // A dead Wikipedia lookup should never take a market listing down with it.
    return null;
  }
}

const MAPILLARY_API = 'https://graph.mapillary.com/images';

/**
 * How far from a market's own pin to look for a street-level photo, in metres. Mapillary's
 * radius search caps this at 50 m; a larger value returns an API error and no photo.
 *
 * Wide enough to catch an image taken across the street rather than only ones tagged to the
 * exact gate, while staying close enough to the market to avoid pulling a neighbouring place.
 */
const GEO_RADIUS_M = 50;

/** The one shape read out of Mapillary's Graph API response; everything else is ignored. */
const MapillaryResponseSchema = z.object({
  data: z.array(z.object({ id: z.string().optional(), thumb_1024_url: z.string().optional() })).optional(),
});

/**
 * A real street-level photo taken near this exact point, or `null` — the fallback for when no
 * Wikipedia article matches the name at all.
 *
 * This is why coordinates are the right second try rather than a looser name search: a small,
 * informal local market almost never has its own Wikipedia article, but the street it sits on
 * is often covered by someone's Mapillary drive or walk. Searching by location rather than
 * name sidesteps the whole "does the title actually match" problem — there is nothing to
 * mismatch, only "is there a photo near here or not".
 *
 * `mapillaryToken` is passed in rather than read from `process.env` here: this module has no
 * boot sequence of its own, so a module-level `process.env` read would run the moment this
 * file is first imported — which, in an ES module graph, can happen *before* whatever loads
 * `.env` at the top of `index.ts` has run. Taking the token as a parameter means it is only
 * ever read from the validated `env` object in `index.ts`, after `.env` is actually loaded.
 */
async function mapillaryPhotoFor(
  fetchImpl: GeocodeFetch,
  lat: number,
  lng: number,
  mapillaryToken: string | undefined,
): Promise<PlacePhoto | null> {
  if (!mapillaryToken) return null;

  const url = `${MAPILLARY_API}?${new URLSearchParams({
    access_token: mapillaryToken,
    lat: String(lat),
    lng: String(lng),
    radius: String(GEO_RADIUS_M),
    limit: '1',
    fields: 'id,thumb_1024_url',
  })}`;

  try {
    const reply = await fetchImpl(url, { headers: {}, signal: AbortSignal.timeout(PHOTO_TIMEOUT_MS) });
    if (!reply.ok) return null;

    const parsed = MapillaryResponseSchema.safeParse(await reply.json());
    if (!parsed.success) return null;

    const image = parsed.data.data?.[0];
    if (!image?.id || !image.thumb_1024_url) return null;
    return {
      url: image.thumb_1024_url,
      credit: 'Mapillary contributors',
      link: `https://www.mapillary.com/app/?pKey=${encodeURIComponent(image.id)}`,
    };
  } catch {
    return null;
  }
}

/**
 * The real photo for one candidate: the name-matched Wikipedia article if one exists, else
 * whatever Mapillary has geotagged near its coordinates, else `null`.
 *
 * Name first because a matched article's photo is *of* the place by construction; location
 * second because it is the wider net that catches everything a name search cannot.
 */
async function bestPhotoFor(
  fetchImpl: GeocodeFetch,
  headers: Record<string, string>,
  candidate: PlaceCandidate,
  mapillaryToken: string | undefined,
): Promise<PlacePhoto | null> {
  // `Market in Lagos` and similar labels are our own area-based placeholders for unnamed OSM
  // nodes, not proper market names. A Wikipedia match on "Lagos" would show a city photo for
  // an individual market, so only allow article photos for names actually supplied by a mapper.
  if (!candidate.name.startsWith('Market in ')) {
    const named = await photoFor(fetchImpl, headers, candidate.name, candidate.city, candidate.lat, candidate.lng);
    if (named) return named;
  }
  return mapillaryPhotoFor(fetchImpl, candidate.lat, candidate.lng, mapillaryToken);
}

/**
 * Runs `bestPhotoFor` across a list of candidates, in parallel, and never rejects.
 *
 * One slow or failing lookup must not hold up — or blank out — the other nine, so this uses
 * `allSettled` rather than `all` and treats a rejection exactly like a `null` photo.
 */
async function withPhotos(
  fetchImpl: GeocodeFetch,
  headers: Record<string, string>,
  candidates: PlaceCandidate[],
  mapillaryToken: string | undefined,
): Promise<PlaceCandidate[]> {
  const results = await Promise.allSettled(
    candidates.map((c) => bestPhotoFor(fetchImpl, headers, c, mapillaryToken)),
  );

  return candidates.map((c, i) => {
    const result = results[i];
    const photo = result !== undefined && result.status === 'fulfilled' ? result.value : null;
    return {
      ...c,
      image_url: photo?.url ?? null,
      image_credit: photo?.credit ?? null,
      image_link: photo?.link ?? null,
    };
  });
}

/**
 * A geocoder that reads Photon over the given fetch.
 *
 * The user agent is not decoration: OpenStreetMap's usage policy asks every client to say
 * what it is, and the default one identifies this as an anonymous Node process, which is the
 * quickest way to be rate-limited without anyone explaining why.
 *
 * `mapillaryToken` is optional and simply threaded down into `withPhotos`: no token means the
 * Mapillary fallback silently yields no photos rather than the server failing to boot.
 */
export function makeGeocoder(
  fetchImpl: GeocodeFetch,
  userAgent: string,
  mapillaryToken?: string,
): Geocoder {
  const headers = { 'user-agent': userAgent, accept: 'application/json' };

  /**
   * One round trip, with the failure vocabulary of this module rather than of the upstream.
   *
   * Both services are treated as unreliable witnesses: a socket that never answers, a throttle,
   * a 500 and a body that is not JSON are four different things out there and one of three codes
   * in here, so a client branches on the spec 9.1 code and never on a stranger's status number.
   */
  async function dial(url: string, init: GeocodeRequest): Promise<unknown> {
    let reply: GeocodeReply;
    try {
      reply = await fetchImpl(url, init);
    } catch (err) {
      throw new ApiError(
        'internal',
        `The place lookup did not answer: ${(err as Error).message}`,
      );
    }

    if (!reply.ok) {
      if (reply.status === 429) {
        throw new ApiError(
          'rate_limited',
          'The place lookup is throttling us. Try the search again in a moment.',
        );
      }
      throw new ApiError('internal', `The place lookup answered ${reply.status}.`);
    }

    return reply.json().catch(() => {
      throw new ApiError('internal', 'The place lookup replied with something that was not JSON.');
    });
  }

  /** Photon, already narrowed by zod, with unusable features dropped. */
  async function ask(query: string, limit: number): Promise<PlaceCandidate[]> {
    const url = `${PHOTON_ENDPOINT}?${new URLSearchParams({
      q: query,
      limit: String(limit),
      bbox: AFRICA_BBOX,
    })}`;
    const body = await dial(url, {
      headers,
      signal: AbortSignal.timeout(TIMEOUT_MS),
    });

    const envelope = PhotonResponseSchema.safeParse(body);
    if (!envelope.success) {
      throw new ApiError('internal', 'The place lookup returned a response this server does not understand.');
    }

    // A feature that fails the shape is dropped rather than failing the search: one
    // malformed result in a list of five should not cost the caller the other four. The
    // Africa filter runs before the slice, not after, so a caller asking for `limit` results
    // still gets up to `limit` — not `limit` minus however many fell outside the continent.
    return envelope.data.features
      .map((feature) => PhotonFeatureSchema.safeParse(feature))
      .filter((r) => r.success)
      .map((r) => candidateOf(r.data))
      .filter((place) => isInAfrica(place.country))
      .slice(0, limit);
  }

  /**
   * Overpass, which takes the query in a form body rather than in a parameter — tried against
 * each mirror in turn.
 *
 * A mirror that times out, 504s, or throttles us is not the same failure as all mirrors being
 * down, so only the last mirror's error is the one a caller ever sees. Anything that is *not*
 * an upstream-flakiness code — a validation bug in our own query, say — is thrown immediately
 * instead of being retried for no reason. On a transient mirror failure we also ask Photon for
 * named marketplaces inside the same box. Photon supports a bounding-box filter and returns
 * the same OSM marketplace tags; this keeps map discovery and its place-photo lookups moving
 * when the volunteer Overpass mirrors are slow.
 */
  async function askPhotonBox(box: MarketBox, wanted: number): Promise<PlaceCandidate[]> {
    const bbox = [box.west, box.south, box.east, box.north].join(',');
    const url = `${PHOTON_ENDPOINT}?${new URLSearchParams({
      q: 'market',
      limit: String(MAX_UPSTREAM_LIMIT),
      bbox,
    })}`;
    const raw = await dial(url, { headers, signal: AbortSignal.timeout(TIMEOUT_MS) });
    const envelope = PhotonResponseSchema.safeParse(raw);
    if (!envelope.success) throw new ApiError('internal', 'The place lookup returned a response this server does not understand.');
    return envelope.data.features
      .map((feature) => PhotonFeatureSchema.safeParse(feature))
      .filter((result) => result.success)
      .map((result) => candidateOf(result.data))
      .filter((place) => place.kind === MARKETPLACE_KIND && place.name !== 'Unnamed place')
      .slice(0, wanted);
  }

  async function askBox(box: MarketBox, wanted: number): Promise<PlaceCandidate[]> {
    const body = new URLSearchParams({ data: boxQuery(box, wanted) }).toString();
    let lastErr: unknown;

    for (const endpoint of OVERPASS_ENDPOINTS) {
      try {
        const raw = await dial(endpoint, {
          headers: { ...headers, 'content-type': 'application/x-www-form-urlencoded' },
          method: 'POST',
          body,
          signal: AbortSignal.timeout(OVERPASS_TIMEOUT_S * 1000),
        });

        const envelope = OverpassResponseSchema.safeParse(raw);
        if (!envelope.success) {
          throw new ApiError('internal', 'The place lookup returned a response this server does not understand.');
        }

        return envelope.data.elements
          .map((element) => OverpassElementSchema.safeParse(element))
          .filter((r) => r.success)
          .map((r) => boxCandidateOf(r.data))
          .slice(0, wanted);
      } catch (err) {
        lastErr = err;
        // Only an upstream-flakiness error is worth trying the next mirror for. A shape error
        // on our own zod schema would fail on every mirror the same way, so it is not one.
        const retryable = err instanceof ApiError && (err.code === 'internal' || err.code === 'rate_limited');
        if (!retryable) throw err;
        try {
          const fallback = await askPhotonBox(box, wanted);
          if (fallback.length > 0) return fallback;
        } catch {
          // Keep trying the other Overpass mirrors if Photon is also unavailable.
        }
      }
    }

    throw lastErr;
  }

  return {
    search: (query, limit) => ask(query, Math.min(limit, MAX_UPSTREAM_LIMIT)),

    // The tag filter happens here because the gazetteer cannot do it. Over-fetching is the
    // only way to hand back `limit` markets rather than `limit` results of which two are.
    // Photos are looked up last and only for the final `limit` rows — never for the discarded
    // over-fetch — since a Wikipedia miss costs nothing but is still a wasted call otherwise.
    async markets(query, limit) {
      const fetched = await ask(asMarketQuery(query), Math.min(limit * OVERFETCH, MAX_UPSTREAM_LIMIT));
      const kept = fetched.filter((place) => place.kind === MARKETPLACE_KIND).slice(0, limit);
      return withPhotos(fetchImpl, headers, kept, mapillaryToken);
    },

    // The same over-fetch for the same reason: the nodes that carry no `name` are dropped here,
    // so asking for exactly `limit` would answer with fewer whenever a box holds unnamed gates.
    async inBox(box, limit) {
      const fetched = await askBox(box, Math.min(limit * OVERFETCH, MAX_UPSTREAM_LIMIT));
      const kept = fetched.slice(0, limit);
      return withPhotos(fetchImpl, headers, kept, mapillaryToken);
    },
  };
}

/**
 * A cache key for a corner of the map, rounded to two decimals.
 *
 * Keying on the exact corners means a visitor who drags the map a hundred metres asks a new
 * question of a volunteer mirror. At this granularity the worst answer is a ring that sits half a
 * kilometre off where the visitor happened to be looking, which the section already says it is.
 */
function boxKey(box: MarketBox): string {
  const round = (value: number): string => value.toFixed(2);
  return [box.south, box.west, box.north, box.east].map(round).join(',');
}

/**
 * A bounded, short-lived memo in front of a geocoder.
 *
 * This is what lets `/places/markets` answer without a token. An anonymous route onto someone
 * else's gazetteer is a way to spend their goodwill on our visitors' behalf, and the cheapest
 * answer is to ask the question once: a hundred people searching `Lagos` is one upstream call
 * per fifteen minutes, not a hundred. The `q` minimum length and the capped `limit` do the rest.
 *
 * The *promise* is cached rather than its result, so two searches for the same city that arrive
 * together share one round trip instead of each starting their own. A rejection is dropped,
 * since remembering an outage would keep serving a dead lookup after the upstream recovered.
 *
 * The size cap is the point of it being bounded: an unbounded cache on a public endpoint is a
 * memory leak with a search box in front of it. Two hundred entries of ten places each is a few
 * hundred kilobytes however the traffic looks, and the oldest goes when the list is full.
 */
export function makeCachedGeocoder(
  inner: Geocoder,
  ttlMs: number,
  maxEntries = 200,
): Geocoder {
  const entries = new Map<string, { at: number; value: Promise<PlaceCandidate[]> }>();

  function remember(
    method: 'search' | 'markets' | 'inBox',
    query: string,
    limit: number,
    run: () => Promise<PlaceCandidate[]>,
  ): Promise<PlaceCandidate[]> {
    const key = `${method}:${query.trim().toLowerCase()}:${limit}`;
    const now = Date.now();
    const hit = entries.get(key);

    if (hit && now - hit.at < ttlMs) {
      // Re-inserting makes the Map's own order the least-recently-used order.
      entries.delete(key);
      entries.set(key, hit);
      return hit.value;
    }

    if (entries.size >= maxEntries) {
      const oldest = entries.keys().next().value;
      if (oldest !== undefined) entries.delete(oldest);
    }

    const value = run().catch((err: unknown) => {
      entries.delete(key);
      throw err;
    });
    entries.set(key, { at: now, value });
    return value;
  }

  return {
    search: (query, limit) =>
      remember('search', query, limit, () => inner.search(query, limit)),
    markets: (query, limit) =>
      remember('markets', query, limit, () => inner.markets(query, limit)),
    inBox: (box, limit) =>
      remember('inBox', boxKey(box), limit, () => inner.inBox(box, limit)),
  };
}

/**
 * The real one, on the platform's own fetch. `index.ts` supplies the user agent and the
 * Mapillary token, both from the validated `env` object — never from a bare `process.env`
 * read inside this module.
 */
export function makeNetworkGeocoder(userAgent: string, mapillaryToken?: string): Geocoder {
  return makeGeocoder(
    (url, init) => fetch(url, init) as unknown as Promise<GeocodeReply>,
    userAgent,
    mapillaryToken,
  );
}
