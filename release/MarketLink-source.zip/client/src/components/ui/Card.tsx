import type { ReactNode } from 'react';

export function Card({ children, className = '' }: { children: ReactNode; className?: string }) {
  return <div className={`motion-card rounded-2xl border border-line bg-surface shadow-[0_12px_36px_rgba(21,39,29,0.07)] ${className}`}>{children}</div>;
}
