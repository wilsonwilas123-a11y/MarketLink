-- MarketLink: full schema + Lagos demo data, flattened for the Supabase SQL Editor.
-- Generated from db/migrations and db/seed. Run once, in this order.

-- ================================================================ migrations/0001_auth_stub_and_helpers.sql
-- Ensures `auth.users` exists, then adds the SQL helpers the rest of the schema relies on.
--
-- On Supabase `auth.users` is real and the guard below is skipped, so this file never
-- touches the managed auth schema. On a plain Postgres instance (local checks, CI) it
-- creates a stand-in so `profiles` has something to point at.

do $auth$
begin
  if to_regclass('auth.users') is null then
    create schema if not exists auth;
    create table auth.users (
      id                 uuid primary key default gen_random_uuid(),
      email              text unique not null,
      phone              text,
      encrypted_password text not null default '',
      email_confirmed_at timestamptz default now(),
      created_at         timestamptz not null default now()
    );
    raise notice 'auth.users is absent; created a local stand-in for testing only';
  end if;
end
$auth$;

-- An ISO week label such as '2026-W39'. `IYYY-IW` is what makes it ISO rather than
-- calendar-based, so a week that straddles New Year is labelled by its Thursday.
create or replace function iso_week(on_date date default current_date)
returns text
language sql
immutable
as $$
  select to_char(on_date, 'IYYY-"W"IW');
$$;

-- Order references read as ML-2048 in the UI. The sequence keeps them short and
-- non-guessable-by-enumeration in aggregate, unlike a row count exposed directly.
create sequence if not exists order_reference_seq start 2048;

create or replace function next_order_reference()
returns text
language sql
volatile
as $$
  select 'ML-' || nextval('order_reference_seq')::text;
$$;

-- ================================================================ migrations/0002_accounts_markets_categories.sql
-- Accounts, markets and the category master list.

create table profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  role        text not null check (role in ('customer', 'farmer', 'admin')),
  full_name   text not null check (length(btrim(full_name)) > 0),
  phone       text not null check (length(btrim(phone)) > 0),
  address     text,
  avatar_url  text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table markets (
  id             uuid primary key default gen_random_uuid(),
  name           text not null check (length(btrim(name)) > 0),
  address        text not null,
  city           text not null,
  state          text not null,
  lat            numeric(9, 6) not null check (lat between -90 and 90),
  lng            numeric(9, 6) not null check (lng between -180 and 180),
  operating_days text[] not null default '{}',
  opens_at       time not null,
  closes_at      time not null,
  image_url      text,
  is_active      boolean not null default true,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now(),

  -- An overnight market would need a wrap-around rule; none in the seed has one, so
  -- rejecting it here is cheaper than reasoning about it everywhere it is read.
  constraint markets_open_before_close check (opens_at < closes_at)
);

create table categories (
  id         uuid primary key default gen_random_uuid(),
  name       text not null unique check (length(btrim(name)) > 0),
  slug       text not null unique check (slug ~ '^[a-z][a-z0-9-]*$'),
  icon_key   text not null,
  sort_order int not null default 0
);

-- Listing searches filter on city and read active markets only; the admin table sorts
-- by name, so give both a home rather than seq-scanning as the rows grow.
create index markets_city_idx on markets (city);
create index markets_active_idx on markets (is_active);
create index categories_sort_idx on categories (sort_order);

-- ================================================================ migrations/0003_farmers_and_market_roster.sql
-- Vendor stalls and which market each one trades at.

create table farmers (
  id                    uuid primary key default gen_random_uuid(),
  profile_id            uuid not null unique references profiles (id) on delete cascade,
  stall_name            text not null check (length(btrim(stall_name)) > 0),
  contact_person        text,
  description           text,
  logo_url              text,
  cover_url             text,
  lat                   numeric(9, 6) check (lat between -90 and 90),
  lng                   numeric(9, 6) check (lng between -180 and 180),
  operating_days        text[] not null default '{}',
  pickup_window_start   time,
  pickup_window_end     time,
  order_cutoff_minutes  int not null default 120 check (order_cutoff_minutes >= 0),
  status                text not null default 'pending'
                        check (status in ('pending', 'approved', 'suspended')),
  rating_avg            numeric(3, 2) not null default 0 check (rating_avg between 0 and 5),
  rating_count          int not null default 0 check (rating_count >= 0),
  created_at            timestamptz not null default now(),
  updated_at            timestamptz not null default now(),

  constraint farmers_pickup_window_ordered
    check (pickup_window_start is null or pickup_window_end is null
           or pickup_window_start < pickup_window_end)
);

-- `/farmers/me` resolves a caller to a single stall, which is what the unique
-- profile_id above guarantees; the public roster only ever reads approved farmers.
create index farmers_status_idx on farmers (status);
create index farmers_location_idx on farmers (lat, lng);

create table market_farmers (
  market_id uuid not null references markets (id) on delete cascade,
  farmer_id uuid not null references farmers (id) on delete cascade,
  stall_ref text,
  days      text[] not null default '{}',
  primary key (market_id, farmer_id)
);

create index market_farmers_farmer_idx on market_farmers (farmer_id);

-- ================================================================ migrations/0004_products_and_weekly_stock.sql
-- Product listings and their per-week availability.

create table products (
  id            uuid primary key default gen_random_uuid(),
  farmer_id     uuid not null references farmers (id) on delete cascade,
  category_id   uuid not null references categories (id) on delete restrict,
  name          text not null check (length(btrim(name)) > 0),
  description   text,
  unit          text not null check (unit in ('basket', 'bunch', 'pack', 'crate', 'l', 'kg')),
  price_kobo    bigint not null check (price_kobo > 0),
  image_urls    text[] not null default '{}',
  template_qty  int not null default 0 check (template_qty >= 0),
  is_organic    boolean not null default false,
  is_active     boolean not null default true,
  rating_avg    numeric(3, 2) not null default 0 check (rating_avg between 0 and 5),
  rating_count  int not null default 0 check (rating_count >= 0),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index products_farmer_idx on products (farmer_id);
create index products_category_price_idx on products (category_id, price_kobo);
create index products_active_idx on products (is_active);

-- One row per product per ISO week. The week column is deliberately free-form text
-- matching iso_week()'s shape rather than a date, so '2026-W39' can be looked up
-- directly by the same string the API computes.
create table weekly_stock (
  product_id         uuid not null references products (id) on delete cascade,
  week               text not null check (week ~ '^[0-9]{4}-W[0-9]{2}$'),
  quantity_available int not null check (quantity_available >= 0),
  is_sold_out        boolean not null default false,
  updated_at         timestamptz not null default now(),

  primary key (product_id, week)
);

-- The stock reset reads every one of a farmer's products for one week.
create index weekly_stock_product_week_idx on weekly_stock (product_id, week desc);

-- ================================================================ migrations/0005_orders_and_items.sql
-- Orders and their line items. One farmer per order; a mixed cart is split before insert
-- (spec 4.14), so nothing here has to model a multi-stall pickup.

create table orders (
  id                 uuid primary key default gen_random_uuid(),
  reference          text not null unique default next_order_reference(),
  customer_id        uuid not null references profiles (id) on delete restrict,
  farmer_id          uuid not null references farmers (id) on delete restrict,
  market_id          uuid not null references markets (id) on delete restrict,
  status             text not null default 'placed'
                     check (status in ('placed', 'accepted', 'preparing',
                                       'ready_for_pickup', 'completed', 'cancelled')),
  subtotal_kobo      bigint not null check (subtotal_kobo >= 0),
  delivery_fee_kobo  bigint not null default 0 check (delivery_fee_kobo = 0),
  pickup_date        date not null,
  pickup_slot_start  time not null,
  pickup_slot_end    time not null,
  cutoff_at          timestamptz not null,
  placed_at          timestamptz not null default now(),
  accepted_at        timestamptz,
  ready_at           timestamptz,
  completed_at       timestamptz,
  cancelled_at       timestamptz,
  cancel_reason      text,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now(),

  constraint orders_slot_ordered check (pickup_slot_start < pickup_slot_end)
);

create index orders_customer_idx on orders (customer_id, placed_at desc);
create index orders_farmer_idx on orders (farmer_id, status);
create index orders_reference_idx on orders (reference);

create table order_items (
  order_id             uuid not null references orders (id) on delete cascade,
  product_id           uuid not null references products (id) on delete restrict,
  -- Snapshots: a farmer repricing or renaming a product must not rewrite history,
  -- and a receipt that changes under the customer is worse than no receipt.
  product_name_snapshot  text not null,
  unit_snapshot          text not null,
  price_kobo_snapshot    bigint not null check (price_kobo_snapshot >= 0),
  quantity               int not null check (quantity > 0),

  primary key (order_id, product_id)
);

create index order_items_product_idx on order_items (product_id);

-- ================================================================ migrations/0006_reviews_favorites_notifications.sql
-- Reviews, favourites and in-app notifications.

create table reviews (
  id           uuid primary key default gen_random_uuid(),
  order_id     uuid not null references orders (id) on delete cascade,
  product_id   uuid not null references products (id) on delete cascade,
  farmer_id    uuid not null references farmers (id) on delete cascade,
  customer_id  uuid not null references profiles (id) on delete cascade,
  rating       int not null check (rating between 1 and 5),
  title        text,
  body         text,
  farmer_reply text,
  replied_at   timestamptz,
  status       text not null default 'visible' check (status in ('visible', 'removed')),
  created_at   timestamptz not null default now(),

  -- One review per product per order, enforced here so a double-click cannot post twice
  -- even if the UI check is bypassed.
  constraint reviews_once_per_order_product unique (order_id, product_id)
);

create index reviews_product_idx on reviews (product_id, created_at desc);
create index reviews_farmer_idx on reviews (farmer_id, created_at desc);

-- Favourites point at either a farmer or a product. The two-sided FKs below mean a
-- target has to exist in one of the two tables; the trigger in 0007 makes that
-- exclusive-or explicit, since a row cannot tell which table its uuid came from.
create table favorites (
  id          uuid primary key default gen_random_uuid(),
  profile_id  uuid not null references profiles (id) on delete cascade,
  target_type text not null check (target_type in ('farmer', 'product')),
  target_id   uuid not null,
  created_at  timestamptz not null default now(),

  constraint favorites_once_per_target unique (profile_id, target_type, target_id)
);

create index favorites_profile_idx on favorites (profile_id, target_type);

create table notifications (
  id         uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles (id) on delete cascade,
  kind       text not null check (kind in ('order_placed', 'order_accepted', 'order_ready',
                                           'order_cancelled', 'stock_low', 'announcement')),
  title      text not null,
  body       text not null,
  link       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);

create index notifications_unread_idx on notifications (profile_id, read_at, created_at desc);

-- ================================================================ migrations/0007_timestamps_and_favorite_target.sql
-- Row-level plumbing only. Aggregation and order-state rules stay in the Node service
-- layer per the architecture decision; these triggers exist because the database is the
-- only place that can guarantee them on every write path.

create or replace function set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at := now();
  return new;
end
$$;

-- profiles, markets, farmers, products, weekly_stock and orders all carry updated_at.
do $trg$
declare
  t text;
begin
  foreach t in array array['profiles', 'markets', 'farmers', 'products', 'weekly_stock', 'orders']
  loop
    execute format('drop trigger if exists set_updated_at on %I', t);
    execute format(
      'create trigger set_updated_at before update on %I for each row execute function set_updated_at()',
      t
    );
  end loop;
end
$trg$;

-- `favorites.target_id` is polymorphic, so no foreign key can cover it and a dangling
-- target would render a broken card. This asserts the uuid exists in the table the
-- row's own target_type points at — an existence invariant, not business logic.
create or replace function assert_favorite_target_exists()
returns trigger
language plpgsql
as $$
declare
  found boolean;
begin
  if new.target_type = 'farmer' then
    select exists (select 1 from farmers where id = new.target_id) into found;
  else
    select exists (select 1 from products where id = new.target_id) into found;
  end if;

  if not found then
    raise exception 'favorite target % does not exist for target_type %',
      new.target_id, new.target_type
      using errcode = '23503';
  end if;

  return new;
end
$$;

create trigger favorites_target_exists
before insert or update of target_id, target_type on favorites
for each row execute function assert_favorite_target_exists();

-- ================================================================ migrations/0008_row_level_security.sql
-- Row-level security as defence in depth.
--
-- Every legitimate query arrives over Node's service-role connection, which holds
-- BYPASSRLS. These settings exist so that a leaked anon key cannot read the catalogue
-- or another customer's orders straight through PostgREST, even though the API is the
-- only intended door.
--
-- The role checks below are guarded because a bare Postgres instance (local test, CI)
-- has none of Supabase's roles.

do $rls$
declare
  t record;
  has_anon boolean;
  has_authenticated boolean;
  has_service_role boolean;
begin
  -- Supabase ships these roles; a bare Postgres does not. Creating them locally costs
  -- nothing, is skipped on Supabase, and lets the pgTAP suite prove the deny actually
  -- bites instead of only checking that a flag is set.
  if not exists (select 1 from pg_roles where rolname = 'anon') then
    create role anon nologin;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'authenticated') then
    create role authenticated nologin;
  end if;
  if not exists (select 1 from pg_roles where rolname = 'service_role') then
    create role service_role nologin bypassrls;
  end if;

  select exists (select 1 from pg_roles where rolname = 'anon') into has_anon;
  select exists (select 1 from pg_roles where rolname = 'authenticated') into has_authenticated;
  select exists (select 1 from pg_roles where rolname = 'service_role') into has_service_role;

  for t in
    select c.relname
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public'
      and c.relkind = 'r'
    order by c.relname
  loop
    execute format('alter table %I enable row level security', t.relname);

    -- Owners bypass RLS silently; forcing it closes that gap for the table owner too.
    execute format('alter table %I force row level security', t.relname);

    -- Belt and braces: an explicit deny is easier to spot in a review than the absence
    -- of a policy, and it survives someone later adding a permissive default.
    execute format(
      'drop policy if exists "deny non-service" on %I', t.relname);
    execute format(
      'create policy "deny non-service" on %I for all to public using (false) with check (false)',
      t.relname
    );

    if has_anon then
      execute format('revoke all on %I from anon', t.relname);
    end if;

    if has_authenticated then
      execute format('revoke all on %I from authenticated', t.relname);
    end if;

    -- service_role normally carries BYPASSRLS, but do not assume it: on a self-hosted
    -- or future-tier setup it may not, and every query in the app would then fail
    -- against a policy that reads as 'deny'.
    if has_service_role then
      execute format('grant all on %I to service_role', t.relname);
    end if;
  end loop;

  if has_service_role then
    execute 'grant usage on schema public to service_role';
    execute 'grant usage on all sequences in schema public to service_role';
  end if;
end
$rls$;

-- ================================================================ migrations/0009_markets_location_idx.sql
-- The distance query bounds first and measures second (spec 10), so the bounding box needs
-- an index to bound against. `markets` had one on `city` only, which is the list filter, not
-- the map one. Same shape as `farmers_location_idx` from 0003, for the same reason.
create index markets_location_idx on markets (lat, lng);

-- ================================================================ migrations/0010_africa_scope.sql
-- MarketLink is not a Lagos-only catalogue, and three things every query so far was allowed
-- to assume are now data: which country a market is in, what its money is called, and which
-- clock it trades on.
--
-- The columns are added nullable, backfilled, then made NOT NULL, rather than created with a
-- `default 'Nigeria'`. A default stays in the schema forever and files a Kumasi market under
-- Nigeria the first time a form omits the field; the constraint below makes that same
-- omission a rejected write instead of a plausible-looking wrong row.

alter table markets add column country text;
alter table markets add column currency text;
alter table markets add column timezone text;

alter table farmers add column country text;
alter table farmers add column currency text;

update markets
  set country = 'Nigeria', currency = 'NGN', timezone = 'Africa/Lagos';

-- A stall's country and money come from the market it trades at, so existing rows are
-- derived here instead of typed a second time. Anyone not yet on a roster falls back to the
-- same values the backfill above just gave every market, which is all the seed contains.
update farmers f
  set country = m.country, currency = m.currency
  from market_farmers mf
  join markets m on m.id = mf.market_id
  where mf.farmer_id = f.id;

update farmers
  set country = 'Nigeria', currency = 'NGN'
  where country is null;

alter table markets alter column country set not null;
alter table markets alter column currency set not null;
alter table markets alter column timezone set not null;
alter table farmers alter column country set not null;
alter table farmers alter column currency set not null;

alter table markets add constraint markets_country_named check (length(btrim(country)) > 0);
alter table markets add constraint markets_currency_iso check (currency ~ '^[A-Z]{3}$');
alter table markets add constraint markets_timezone_iana check (timezone ~ '^[A-Za-z]+/[A-Za-z_-]+$');
alter table farmers add constraint farmers_country_named check (length(btrim(country)) > 0);
alter table farmers add constraint farmers_currency_iso check (currency ~ '^[A-Z]{3}$');

-- `timezone` is checked for shape, not against `pg_timezone_names`, because a check cannot
-- run a subquery. That is the cheaper half of the guarantee: 'GMT' and 'lagos' are refused
-- at the door, and a well-formed name that turns out not to exist still fails loudly at the
-- first query that reads the row rather than quietly answering "closed".

-- The discovery screen filters by country the same way it already filters by city.
create index markets_country_idx on markets (country);

-- 'kobo' names one country's subunit, and every other country on the continent has a
-- different one with a different count per unit. 'minor' is the neutral word for "the
-- smallest whole number this money comes in", which is the only thing the column ever
-- stored; which minor unit it is now travels with the row's currency instead of with the
-- column name.
alter table products rename column price_kobo to price_minor;
alter table products rename constraint products_price_kobo_check to products_price_minor_check;

-- `orders.subtotal_kobo` and `order_items.price_kobo_snapshot` keep their names: no order
-- can be written through the API yet, so renaming them now would be a guess at a shape that
-- has no caller. They take the same treatment when the order flow opens.

-- ================================================================ seed/0001_lagos_core.sql
-- Lagos demo data: 3 markets, 5 categories, 9 farmer stalls (8 approved + 1 pending),
-- 4 customers, ~40 products, and stock rows for the current ISO week.
--
-- Every id derives from md5() of its seed key so re-running this file is safe; each
-- insert ends in ON CONFLICT DO NOTHING.

-- Demo accounts need a password hash, so Supabase's normal signup path can log them in.
-- `extensions` is where Supabase already keeps pgcrypto; creating it locally keeps the
-- qualification below identical in both places.
create schema if not exists extensions;
create extension if not exists pgcrypto with schema extensions;

-- ---------------------------------------------------------------- auth + profiles

-- All demo accounts share this password. It is demo data on a public free tier, not a
-- credential anyone should reuse.
insert into auth.users (id, email, phone, encrypted_password, email_confirmed_at)
select
  md5('marketlink-demo-' || u.key)::uuid,
  u.key || '@marketlink.test',
  u.phone,
  extensions.crypt('marketlink-demo', extensions.gen_salt('bf')),
  now()
from (values
  ('adaeze',    '+2348031120001'),
  ('tunde',     '+2348031120002'),
  ('zainab',    '+2348031120003'),
  ('emeka',     '+2348031120004'),
  ('bola',      '+2348031120101'),
  ('chidinma',  '+2348031120102'),
  ('yahaya',    '+2348031120103'),
  ('grace',     '+2348031120104'),
  ('sunday',    '+2348031120105'),
  ('ifaturo',   '+2348031120106'),
  ('kelechi',   '+2348031120107'),
  ('mariam',    '+2348031120108'),
  ('seun',      '+2348031120109'),
  ('admin',     '+2348031120900')
) as u (key, phone)
on conflict (id) do nothing;

insert into profiles (id, role, full_name, phone, address, is_active)
select md5('marketlink-demo-' || p.key)::uuid, p.role, p.name, p.phone, p.address, true
from (values
  ('adaeze',   'customer', 'Adaeze Obi',      '+2348031120001', 'Allen Avenue, Ikeja'),
  ('tunde',    'customer', 'Tunde Bakare',    '+2348031120002', 'Adekunle Jones, Surulere'),
  ('zainab',   'customer', 'Zainab Yusuf',    '+2348031120003', 'Akin Olugbade, Bolade'),
  ('emeka',    'customer', 'Emeka Nwosu',     '+2348031120004', 'Cementary Road, Yaba'),
  ('bola',     'farmer',   'Bola Adeyemi',    '+2348031120101', 'Mile 12, Ojo'),
  ('chidinma', 'farmer',   'Chidinma Eze',    '+2348031120102', 'Akiode Street, Ojota'),
  ('yahaya',   'farmer',   'Yahaya Sanni',    '+2348031120103', 'Mile 12, Ojo'),
  ('grace',    'farmer',   'Grace Effiong',   '+2348031120104', 'Ikotun Phase 2'),
  ('sunday',   'farmer',   'Sunday Ochelula', '+2348031120105', 'Owode Onirin'),
  ('ifaturo',  'farmer',   'Ifaturo Ade',     '+2348031120106', 'Eta Beach, Epe Road'),
  ('kelechi',  'farmer',   'Kelechi Anyanwu', '+2348031120107', 'Ketu Bus Stop'),
  ('mariam',   'farmer',   'Mariam Lawal',    '+2348031120108', 'Ojodu Berger'),
  ('seun',     'farmer',   'Seun Oluwale',    '+2348031120109', 'Idimu Road'),
  ('admin',    'admin',    'MarketLink Admin','+2348031120900', 'Lagos Island')
) as p (key, role, name, phone, address)
on conflict (id) do nothing;

-- ---------------------------------------------------------------- markets

insert into markets (id, name, address, city, state, lat, lng, operating_days, opens_at, closes_at, image_url, is_active,
                     country, currency, timezone)
values
  (md5('ml-market-mile12')::uuid, 'Mile 12 International Market',
   'Ikorodu Road, Mile 12, Ojo', 'Lagos', 'Lagos', 6.595500, 3.343300,
   array['tue','thu','sat','sun'], time '07:00', time '17:00',
   '/img/markets/mile-12.jpg', true, 'Nigeria', 'NGN', 'Africa/Lagos'),
  (md5('ml-market-oyingbo')::uuid, 'Oyingbo Market',
   'Oyingbo Road, off Iddo Road, Ebute-Metta', 'Lagos', 'Lagos', 6.476600, 3.383900,
   array['mon','wed','fri'], time '08:00', time '16:30',
   '/img/markets/oyingbo.jpg', true, 'Nigeria', 'NGN', 'Africa/Lagos'),
  (md5('ml-market-oshodi')::uuid, 'Oshodi Market',
   'Alhaji Masha Way, Oshodi', 'Lagos', 'Lagos', 6.567000, 3.342100,
   array['sat','sun'], time '06:30', time '18:00',
   '/img/markets/oshodi.jpg', true, 'Nigeria', 'NGN', 'Africa/Lagos')
on conflict (id) do nothing;

/* Mile 12 is one market, not two. A database seeded while the second copy stood at Admiralty Way
   is folded back into this row: the copy's two growers move across, their stall coordinates come
   with them, and the copy is deleted. The last statement carries the name and the Sunday the
   insert above cannot give a row that already exists. Each is a no-op once that has run. */
update farmers set lat = 6.595500, lng = 3.343300
 where id in (md5('marketlink-demo-yahaya')::uuid, md5('marketlink-demo-ifaturo')::uuid);

update market_farmers set market_id = md5('ml-market-mile12')::uuid
 where market_id = md5('ml-market-lekki')::uuid;

delete from markets where id = md5('ml-market-lekki')::uuid;

update markets set name = 'Mile 12 International Market',
                   operating_days = array['tue','thu','sat','sun']
 where id = md5('ml-market-mile12')::uuid;

/* Balogun is out of the demo and Oyingbo takes its place. The two growers rostered to it move
   across with their stall coordinates, and the old row goes after them: orders name a market and
   refuse the delete while any survive, so the re-point has to come first. */
update farmers set lat = 6.476600, lng = 3.383900
 where id in (md5('marketlink-demo-sunday')::uuid, md5('marketlink-demo-seun')::uuid);

update market_farmers set market_id = md5('ml-market-oyingbo')::uuid
 where market_id = md5('ml-market-balogun')::uuid;

delete from markets where id = md5('ml-market-balogun')::uuid;

/* The pin was first guessed at Jiboku Cross, which is four kilometres from the market. Restated
   here because the insert above will not rewrite a row a database already holds. */
update markets set address = 'Oyingbo Road, off Iddo Road, Ebute-Metta',
                   lat = 6.476600, lng = 3.383900
 where id = md5('ml-market-oyingbo')::uuid;

/* Named for the market he used to trade at, and now wrong twice over. */
update profiles set address = 'Mile 12, Ojo'
 where id = md5('marketlink-demo-yahaya')::uuid;

-- ---------------------------------------------------------------- categories

insert into categories (id, name, slug, icon_key, sort_order)
values
  (md5('ml-cat-vegetables')::uuid, 'Vegetables', 'vegetables', 'leaf',       1),
  (md5('ml-cat-fruits')::uuid,     'Fruits',     'fruits',     'apple',      2),
  (md5('ml-cat-dairy')::uuid,      'Dairy',      'dairy',      'milk',       3),
  (md5('ml-cat-bakery')::uuid,     'Bakery',     'bakery',     'bread',      4),
  (md5('ml-cat-herbs')::uuid,      'Herbs',      'herbs',      'sprout',     5)
on conflict (id) do nothing;

-- ---------------------------------------------------------------- farmer stalls

-- Eight approved and one pending, so the admin approval queue has something in it.
insert into farmers (id, profile_id, stall_name, contact_person, description, lat, lng,
                     operating_days, pickup_window_start, pickup_window_end,
                     order_cutoff_minutes, status, rating_avg, rating_count, cover_url,
                     country, currency)
select
  md5('marketlink-demo-' || f.key)::uuid,
  md5('marketlink-demo-' || f.key)::uuid,
  f.stall, f.name, f.blurb, f.lat, f.lng,
  f.days, f.win_start, f.win_end, f.cutoff, f.status, f.ravg, f.rcount,
  '/img/farmers/' || f.key || '.jpg',
  'Nigeria', 'NGN'
from (values
  ('bola',     'Adeyemi Farms',        'Bola Adeyemi',    'Leaf vegetables and tubers grown at Epe, harvested two days before pickup.', 6.595500, 3.343300, array['tue','thu','sat'], time '08:00', time '12:00', 180, 'approved', 4.60, 38),
  ('chidinma', 'Eze Fresh Produce',    'Chidinma Eze',    'Peppers, tomatoes and onions sold by the crate.',                             6.567000, 3.342100, array['sat','sun'],      time '09:00', time '13:00', 120, 'approved', 4.30, 51),
  ('yahaya',   'Sanni Farms',          'Yahaya Sanni',    'Fresh cabbage and leafy greens, grown and harvested locally in Epe.',         6.595500, 3.343300, array['sat','sun'],      time '10:00', time '14:00', 240, 'approved', 4.80, 27),
  ('grace',    'Effiong Veg Baskets',  'Grace Effiong',   'Mixed vegetable baskets sized for a household week.',                         6.595500, 3.343300, array['tue','thu'],      time '07:30', time '11:30', 120, 'approved', 4.10, 19),
  ('sunday',   'Ochelula Herbs',       'Sunday Ochelula', 'Scent leaf, bitter leaf and curry leaf, cut and tied by hand.',                6.476600, 3.383900, array['mon','wed','fri'], time '08:00', time '12:00', 300, 'approved', 4.40, 44),
  ('ifaturo',  'Ade Orchard',          'Ifaturo Ade',     'Seasonal fruit from Epe orchards, picked to order.',                          6.595500, 3.343300, array['sat','sun'],      time '09:30', time '13:30', 120, 'approved', 4.70, 33),
  ('kelechi',  'Anyanwu Bakery',       'Kelechi Anyanwu', 'Cassava bread, plantain chips and agege bread baked nightly.',                6.567000, 3.342100, array['sat','sun'],      time '07:00', time '11:00',  60, 'approved', 4.50, 62),
  ('mariam',   'Lawal Dairy',          'Mariam Lawal',    'Yoghurt, waraki and fresh milk kept cold from farm to stall.',                6.595500, 3.343300, array['tue','thu','sat'], time '07:00', time '10:00', 180, 'approved', 4.20, 15),
  ('seun',     'Oluwale Herb Stand',   'Seun Oluwale',    'Scent leaf, curry leaf and bitter tomato, potted or cut.',                    6.476600, 3.383900, array['mon','wed','fri'], time '08:30', time '12:30', 120, 'pending',  0.00,  0)
) as f (key, stall, name, blurb, lat, lng, days, win_start, win_end, cutoff, status, ravg, rcount)
on conflict (profile_id) do nothing;

-- ---------------------------------------------------------------- roster

insert into market_farmers (market_id, farmer_id, stall_ref, days)
values
  (md5('ml-market-mile12')::uuid, md5('marketlink-demo-bola')::uuid,     'A12', array['tue','thu']),
  (md5('ml-market-oshodi')::uuid, md5('marketlink-demo-chidinma')::uuid, 'B04', array['sat','sun']),
  (md5('ml-market-mile12')::uuid, md5('marketlink-demo-yahaya')::uuid,   'F01', array['sat']),
  (md5('ml-market-mile12')::uuid, md5('marketlink-demo-grace')::uuid,    'A18', array['tue','thu']),
  (md5('ml-market-oyingbo')::uuid,md5('marketlink-demo-sunday')::uuid,   'C22', array['mon','wed']),
  (md5('ml-market-mile12')::uuid, md5('marketlink-demo-ifaturo')::uuid,  'F07', array['sat','sun']),
  (md5('ml-market-oshodi')::uuid, md5('marketlink-demo-kelechi')::uuid,  'B11', array['sat','sun']),
  (md5('ml-market-mile12')::uuid, md5('marketlink-demo-mariam')::uuid,   'D03', array['tue','thu','sat']),
  (md5('ml-market-oyingbo')::uuid,md5('marketlink-demo-seun')::uuid,     'C30', array['fri'])
on conflict (market_id, farmer_id) do nothing;

-- ---------------------------------------------------------------- corrections
-- Every insert above is `do nothing`, so a row that already exists keeps whatever it was first
-- seeded with. Restate changed values here so re-running this file fixes an existing database.
-- The scope columns migration 0010 adds need no such restatement: that file backfills them with
-- exactly the values the inserts above carry, so old rows and new rows cannot diverge.

update farmers
   set stall_name = 'Sanni Farms',
       description = 'Fresh cabbage and leafy greens, grown and harvested locally in Epe.'
 where id = md5('marketlink-demo-yahaya')::uuid;

-- ================================================================ seed/0002_lagos_products.sql
-- ~40 listings across the eight approved stalls, plus a stock row for each in the
-- current ISO week. Seun Oluwale is still pending, so their stall deliberately has
-- nothing published — that is what the listing gate in spec 4.3 is for.

insert into products (id, farmer_id, category_id, name, description, unit, price_minor,
                      image_urls, template_qty, is_organic, is_active,
                      rating_avg, rating_count)
select
  md5('ml-product-' || p.key)::uuid,
  md5('marketlink-demo-' || p.stall)::uuid,
  c.id,
  p.name, p.blurb, p.unit, p.price,
  '{}', p.qty, p.organic, true, p.ravg, p.rcount
from (values
  -- Adeyemi Farms — leaf vegetables and tubers
  ('ugu-500',       'bola', 'vegetables', 'Ugu (Pumpkin Leaves)',        'Ten thick ugu leaves, stems trimmed.',                'bunch',  80000,  60, false, 4.70, 22),
  ('efo-shoko',     'bola', 'vegetables', 'Efo Shoko',                   'A dense bundle of wild spinach.',                     'bunch',  60000,  45, false, 4.50, 18),
  ('efo-alako',     'bola', 'vegetables', 'Efo Alako',                   'Fluted dandelion, picked this morning.',              'bunch',  55000,  40, true,  4.30, 11),
  ('gboma',         'bola', 'vegetables', 'Gboma',                       'Gboma leaves for soups and stews.',                   'bunch',  50000,  50, false, 4.20,  9),
  ('waterleaf',     'bola', 'vegetables', 'Waterleaf',                   'Fresh waterleaf bundles, washed.',                    'bunch',  45000,  35, true,  4.10,  7),
  ('yam-tuber',     'bola', 'vegetables', 'Puna Yam Tuber',              'A medium puna tuber, roughly 3kg.',                   'crate', 450000,  24, false, 4.60, 31),
  ('coco-yam',      'bola', 'vegetables', 'Coco Yam',                    'Elephant yam, cut to a cooking size.',                'crate', 380000,  18, false, 4.40, 14),
  ('sweet-potato',  'bola', 'vegetables', 'Sweet Potato',                'Orange-flesh sweet potato, graded medium.',           'kg',    120000,  30, false, 4.35, 12),

  -- Eze Fresh Produce — peppers, tomatoes, onions
  ('tatashe-crate', 'chidinma', 'vegetables', 'Tatashe (Bell Pepper)',   'A crate of firm red tatashe.',                        'crate', 650000,  12, false, 4.40, 26),
  ('shombo-crate',  'chidinma', 'vegetables', 'Shombo (Chilli Pepper)',  'Hot shombo, sorted by size.',                         'crate', 480000,  15, false, 4.60, 33),
  ('rodo-crate',    'chidinma', 'vegetables', 'Rodo (Habanero)',         'Scotch bonnet, harvested at colour.',                 'crate', 520000,  14, false, 4.55, 41),
  ('tomato-crate',  'chidinma', 'vegetables', 'Tomato (Fresh)',          'Roma-type tomatoes, no crush.',                       'crate', 900000,   9, false, 4.10, 20),
  ('onion-net',     'chidinma', 'vegetables', 'Onion',                   'A net of dry onions, about 5kg.',                     'pack',  750000,  20, false, 4.25, 17),
  ('garden-egg',    'chidinma', 'vegetables', 'Garden Egg',              'Purple garden egg, picked young.',                    'bunch',  70000,  28, false, 4.05,  8),

  -- Effiong Veg Baskets — mixed household baskets
  ('basket-soup',   'grace', 'vegetables', 'Soup Basket',                'Ugu, efo, waterleaf and pepper for one pot.',         'basket', 1200000, 16, false, 4.30, 13),
  ('basket-week',   'grace', 'vegetables', 'Household Week Basket',       'Seven days of leaf veg for a family of four.',        'basket', 2400000,  8, false, 4.00,  6),
  ('basket-starter','grace', 'vegetables', 'Starter Basket',              'A small first-week basket for a new kitchen.',        'basket',  900000, 12, true,  3.90,  4),
  ('basket-organic','grace', 'vegetables', 'Organic Leaf Basket',         'Certified-organic leaves, no synthetic spray.',       'basket', 1800000,  6, true,  4.80,  9),

  -- Ochelula Herbs
  ('scent-leaf',    'sunday', 'herbs', 'Scent Leaf (Nchanwu)',           'A hand-tied bunch of nchanwu.',                      'bunch',  70000,  40, true,  4.90, 44),
  ('bitter-leaf',   'sunday', 'herbs', 'Bitter Leaf',                    'Washed bitter leaf, de-bittered on request.',         'bunch',  65000,  36, false, 4.40, 19),
  ('curry-leaf',    'sunday', 'herbs', 'Curry Leaf',                     'Fresh curry leaf sprigs.',                            'bunch',  40000,  55, false, 4.20, 12),
  ('tulasi',        'sunday', 'herbs', 'Tulasi (Holy Basil)',            'Tulasi cut for tea and soups.',                       'bunch',  45000,  30, true,  4.60,  8),
  ('ginger-root',   'sunday', 'herbs', 'Ginger Root',                    'Fat ginger, washed and unpeeled.',                    'kg',    220000,  18, false, 4.35, 15),
  ('garlic-bulb',   'sunday', 'herbs', 'Garlic',                         'Local garlic bulbs, cured.',                          'pack',  180000,  22, false, 4.15, 10),
  ('uda-pods',      'sunday', 'herbs', 'Uda (Negrito Pods)',             'Aromatic uda pods for pepper mixes.',                 'pack',  150000,  25, true,  4.70,  7),

  -- Ade Orchard — fruit
  ('watermelon',    'ifaturo', 'fruits', 'Watermelon',                   'One seeded watermelon, roughly 6kg.',                 'pack',  250000,  40, false, 4.50, 29),
  ('sweet-banana',  'ifaturo', 'fruits', 'Sweet Banana',                 'A hand of ripe sweet banana.',                        'bunch', 120000,  55, false, 4.60, 38),
  ('pineapple',     'ifaturo', 'fruits', 'Sugarloaf Pineapple',          'Gold sugarloaf, cut top left on.',                    'pack',  400000,  26, false, 4.75, 44),
  ('mango',         'ifaturo', 'fruits', 'Mango',                        'Seasonal mango, picked at cheek colour.',             'kg',    150000,  34, false, 4.40, 21),
  ('pawpaw',        'ifaturo', 'fruits', 'Pawpaw',                       'Half a ripe pawpaw, seeds removed.',                  'pack',  180000,  30, false, 4.25, 16),
  ('avocado',       'ifaturo', 'fruits', 'Avocado',                      'Butter avocado, ripened off the tree.',               'kg',    300000,  20, true,  4.80, 18),
  ('orange',        'ifaturo', 'fruits', 'Orange',                       'A crate of pressing oranges.',                        'crate', 850000,  11, false, 4.05,  9),
  ('coconut',       'ifaturo', 'fruits', 'Coconut (Cold)',               'Chilled coconut with the husk trimmed.',              'pack',  150000,  45, false, 4.55, 23),

  -- Anyanwu Bakery
  ('agege-bread',   'kelechi', 'bakery', 'Agege Bread',                  'The daily round loaf, baked overnight.',              'pack',   90000,  70, false, 4.60, 58),
  ('cassava-bread', 'kelechi', 'bakery', 'Cassava Flour Bread',          'Gluten-free loaf in a small tin.',                    'pack',  250000,  25, false, 4.45, 27),
  ('plantain-chips','kelechi', 'bakery', 'Plantain Chips',               'Salted unripe plantain chips, 250g.',                 'pack',  150000,  60, false, 4.70, 49),
  ('coconut-bread', 'kelechi', 'bakery', 'Coconut Bread',                'Soft bread with real coconut through the crumb.',     'pack',  280000,  18, false, 4.30, 14),
  ('chin-chin',     'kelechi', 'bakery', 'Chin Chin',                    'A one-kilo box, crunchy not oily.',                   'pack',  200000,  35, false, 4.50, 31),
  ('meat-pie',      'kelechi', 'bakery', 'Meat Pie',                     'Hand-filled pies, six to a pack.',                    'pack',  350000,  15, false, 4.20, 12),

  -- Lawal Dairy
  ('fresh-milk',    'mariam', 'dairy', 'Fresh Milk',                     'Half a litre of unpasteurised farm milk.',            'l',     200000,  30, false, 4.40, 24),
  ('yoghurt-natural','mariam','dairy', 'Yoghurt (Natural)',              'Set yoghurt, no added sugar, 500ml.',                  'l',     350000,  22, false, 4.65, 33),
  ('waraki',        'mariam', 'dairy', 'Waraki (Soft Cheese)',           'Traditional white cheese, cut to order.',             'pack',  400000,  14, false, 4.55, 16),
  ('butter-250',    'mariam', 'dairy', 'Farm Butter',                    'Cultured butter, 250g block.',                        'pack',  450000,  12, false, 4.35,  9),
  ('noni-juice',    'mariam', 'dairy', 'Fermented Milk (Noni)',          'Turbubo-style fermented milk with noni.',             'l',     300000,  16, false, 4.10,  6),

  -- Sanni Farms — cabbage and leafy greens out of Epe
  ('cabbage-head',  'yahaya', 'vegetables', 'Cabbage (Whole Head)',           'One firm head, outer leaves trimmed off.',                'pack',   350000, 24, false, 4.75, 31),
  ('cabbage-half',  'yahaya', 'vegetables', 'Cabbage (Cut Half)',             'Half a head for a small kitchen.',                        'pack',   180000, 30, false, 4.45, 17),
  ('greens-basket', 'yahaya', 'vegetables', 'Cabbage and Greens Basket',      'Two heads with spring onion and scent leaf tied in.',     'basket', 750000, 10, true,  4.85, 12)
) as p (key, stall, cat_slug, name, blurb, unit, price, qty, organic, ravg, rcount)
join categories c on c.slug = p.cat_slug
on conflict (id) do nothing;

-- Stock for the week the seed is applied in, so the "n left" badge is meaningful on a
-- fresh deploy without a scheduler. The reset endpoint in spec 4.7 copies template_qty
-- forward for later weeks.
insert into weekly_stock (product_id, week, quantity_available, is_sold_out)
select id, iso_week(current_date),
       -- Two lines are shown part-sold so the low-stock badge has something to catch.
       case when name in ('Efo Shoko', 'Mango') then greatest(template_qty / 4, 1)
            else template_qty end,
       false
from products
on conflict (product_id, week) do nothing;

-- One sold-out line exercises the manual override the product card reads.
update weekly_stock
   set is_sold_out = true
 where week = iso_week(current_date)
   and product_id = md5('ml-product-basket-organic')::uuid;

-- ---------------------------------------------------------------- corrections
-- The insert above is `do nothing`, so a database seeded while this stall was still selling dairy
-- keeps those rows next to the new ones. Retire them; weekly_stock cascades away with each product.

delete from products
 where id in (
   md5('ml-product-eggs-tray')::uuid,
   md5('ml-product-eggs-half')::uuid,
   md5('ml-product-cream-line')::uuid
 );
