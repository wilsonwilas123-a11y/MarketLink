import { Suspense } from 'react';
import { useLocation, useRoutes } from 'react-router-dom';
import { TopNav } from './components/layout/TopNav';
import { Footer } from './components/layout/Footer';
import { routes } from './routes';
import { useAuth } from './auth/AuthProvider';

export default function App() {
  const location = useLocation();
  const { status } = useAuth();
  const isAuthScreen = ['/signin', '/signup', '/complete-profile'].includes(location.pathname)
    || (location.pathname === '/' && status !== 'ready');

  return (
    <div className="flex min-h-screen flex-col">
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-full focus:bg-accent focus:px-4 focus:py-2 focus:text-on-block"
      >
        Skip to content
      </a>
      {!isAuthScreen ? <TopNav /> : null}
      <main id="main" className="flex-1">
        <Suspense
          fallback={
            <section className="mx-auto w-full max-w-5xl px-4 py-16" role="status">
              <p className="text-sm text-muted">Loading MarketLink…</p>
            </section>
          }
        >
          {useRoutes(routes)}
        </Suspense>
      </main>
      {!isAuthScreen ? <Footer /> : null}
    </div>
  );
}
